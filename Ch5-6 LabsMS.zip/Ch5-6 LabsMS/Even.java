public class Even{
    public static void main(String[] args){
        int x = 4;
        while (x < 18){
            x += 2;
            System.out.println(x);
        }
    }
}