public class WarmUp{
    public static void main(String[] args){
        System.out.println("\"java\n\tis\n\t\thot!\"");
    }
}