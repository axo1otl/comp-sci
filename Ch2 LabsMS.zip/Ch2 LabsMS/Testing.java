import java.util.Scanner;
public class Testing {
    public static void main (String[] args) {
       /*
       int miles, gallons;
       double mpg;
       
       
       Scanner scan = new Scanner(System.in);
       System.out.print("Enter the number of miles: ");
       miles = scan.nextInt();
       
       System.out.print("Enter the number of gallons: ");
       gallons = scan.nextInt();
       
       mpg = miles / gallons;
       
       System.out.println("Without casting");
       System.out.println(mpg);
       
       mpg = (double)miles / gallons;
       
       System.out.println("With casting");
       System.out.println(mpg);
       */
      
       /*
       int atBats, hits;
       double batAvg;
       
       
       Scanner scan = new Scanner(System.in);
       System.out.print("Enter the number of at bats: ");
       atBats = scan.nextInt();
       
       System.out.print("Enter the number of hits: ");
       hits = scan.nextInt();
       
       batAvg = hits / atBats;
       
       System.out.println("Without casting");
       System.out.println(batAvg);
       
       batAvg = (double)hits / atBats;
       
       System.out.println("With casting");
       System.out.println(batAvg);
       */
      
      
    }
}