public class PlusTest
{
// -------------------------------------------------
// main prints some expressions using the + operator
// -------------------------------------------------
    public static void main (String[] args)
    {
        System.out.println ("This is a long string that is the " +
        "concatenation of two shorter strings.");
        System.out.println ("The first computer was invented about" +
        55 +
        "years ago.");
        System.out.println ("8 plus 5 is " + 8 + 5);
        System.out.println ("8 plus 5 is " + (8 + 5));
        System.out.println (8 + 5 + " equals 8 plus 5.");
}
}

/**
 * 8 plus 5 is 85
 * 8 plus 5 is 13
 * 13 equals 8 plus 5
 */

/** My Answers:
 *  1. There are no parenthases around the 8 + 5 meaning it's a concatenation operator
 *  2. 
 */