public class StudentGrades {
    public static void main (String[] args) {
        System.out.println("///////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
        System.out.println("==          Student Points          ==");
        System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\///////////////////");
        System.out.println("");
        System.out.println("Name\t\tLab\tBonus\tTotal");
        System.out.println("----\t\t---\t-----\t-----");
        System.out.println("Joe\t\t43\t7\t" + (43 + 7));
        System.out.println("William\t\t50\t8\t" + (50 + 8));
        System.out.println("Mary Sue\t39\t10\t" + (39 + 10));
        System.out.println("Matt\t\t41\t16\t" + (41 + 16));
        System.out.println("Madison\t\t22\t9\t" + (22 + 9));
    }
}