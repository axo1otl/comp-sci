// ***************************************************************
// Names.java
//
// Prints a list of student names with their hometowns
// and intended major
// ***************************************************************
public class Names {
// ------------------------
// main prints the list
// ------------------------
    public static void main (String[] args) {
        System.out.println ();
        System.out.println ("\tName\t\tHometown\tMajor");
        System.out.println ("\t====\t\t========\t=====");
        System.out.println ("\tSally\t\tRoanoke\t\tComp Sci");
        System.out.println ("\tAlexander\tWashington\tMath");
        System.out.println ("\tMatt\t\tDanbury\t\tAerospace Engeneering");
        System.out.println ("\tZachary\t\tDanbury\t\tMechanical Engeneering");
        System.out.println ("\tMike\t\tDanbury\t\tEngeneering");
    }
}