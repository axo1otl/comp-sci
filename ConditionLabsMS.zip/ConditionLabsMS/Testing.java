import java.util.Scanner;
public class Testing{
    public static void main (String[] args){
        
    }
}