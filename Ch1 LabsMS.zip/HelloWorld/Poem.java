// Matheus Sekiguchi
// August 31, 2022
// Objective: Following Directions

public class Poem {                               // Class header
    public static void main(String[] args) {      // main header
        System.out.println("Roses are red");
        System.out.println("Violets are blue");   // These all print the
        System.out.println("Sugar is sweet");     // lines of the poem
        System.out.println("And so are you!");    // followed by a new line
    }                                             // Close main
}                                                 // Close header