// =============================== //
// Matheus Sekiguchi
// August 31, 2022
// Objective: Following Directions
// =============================== //

public class Count {                              // Class header
    public static void main(String[] args) {      // main header
        // English
        System.out.println("one two three four five");
        
        // French
        System.out.println("un deux trois quatre cinq");
        
        // Spanish // This is still spanish
        System.out.println("uno dos tres cuatro cinco");
    }                                             // Close main
}                                                 // Close header

/* ANSWERS:
 * 1
 * 2. The program reads better with blank lines
 * 3. Illegal start of expression
 * 4. No problems
 * 5A. I do not violate anything
 * 5B. I do see myself thinking something is easy to understand and
 *     therefore not commenting about it
 *     I also see myself not updating my comments
 */